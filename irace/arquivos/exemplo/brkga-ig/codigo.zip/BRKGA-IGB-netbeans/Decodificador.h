
#ifndef DECODIFICADOR_H
#define DECODIFICADOR_H

#include <list>
#include <vector>
#include <algorithm>
#include "problema.h"

class Decodificador {
public:

    
    Decodificador();
    ~Decodificador();

    double decode(const std::vector< double >& chromosome) const;
    int getN();
    void inicializa(TInstancia *i);
    int defineInstancias(char *nome_instancia, float alfa, int li, float delta, float beta);
    int execucoes();
    void permutacao(const std::vector< double >& chromosome) const;

private:
    TInstancia *instancia;    
    
};

#endif
