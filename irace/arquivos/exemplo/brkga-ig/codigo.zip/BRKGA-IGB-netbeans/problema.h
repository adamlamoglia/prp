
#ifndef PROBLEMA_H_INCLUDED
#define PROBLEMA_H_INCLUDED


/*
   Um program em C para o projeto HC3 (versão 01/11/2014)
   Feito por Bruno Queiroz Pinto

    Esta biblioteca tem o objetivo de representar um problema de quasiclique de cardinalidade máxima

    Contém as seguintes estruturas de dados:
    - TInstancia : Representa uma instância para o problema

    Contém as seguintes Funções:
    - carregarInstancias : Responsável carregar os dados da instância
    - lerarquivo : Função auxiliar, que lê os dados do arquivo da instância. Utilizada pelo carregarInstancia
    - existearesta : Função que verifica se há aresta entre dois vértices.
    - validasolucao : Verifica se a solução é válida.
    - econexo : Verifica se o grafo da solução é conexo, função recursiva utilizada pela função validasolucao
 */

#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "MTRand.h"

#define MAX_V 8000  /* Número máximo de vértices aceito */

/*
    TInstancia : Representa uma instância para o problema
 */
typedef struct {
    float alfa;
    float beta;
    float delta;
    int minsize;
    char *nome_instancia; // nome do arquivo
    int num_vertices; // número de vértices da instância
    int num_arestas; // número de arestas presentes na instância
    float densidade; // densidade alvo presente no arquivo da instância
    int matrizadjacencia[MAX_V][MAX_V]; // matriz de adjacencia dos vértices da instância. matrizadjacencia[X][Y] = 1 representa que há aresta entre X e Y.
    int vetorvizinhos[MAX_V]; // vetor que contém a quantidade de vizinhos de um vértice, define o grau de um vértice.
    int ordem_indice_construir[MAX_V]; // vetor que indica a permutação gerada pela ordenação das |V| primeiras chaves
    int ordem_indice_remover[MAX_V]; // vetor que indica a permutação gerada pela ordenação das |V| ultimas chaves

} TInstancia;

/* Assinatura das funções */
TInstancia* carregarInstancias(char *nome_instancia);
inline int existearesta(TInstancia *instancia, int vertice1, int vertice2);
inline TInstancia* lerarquivo(FILE *fp); /* procedimento responsável em realizar a leitura do arquivo com o grafo em formato bitmap */
inline int get_parametros();
void econexo(TInstancia *instancia, int *s, int tams, int atual, int *conectado);
inline int e_fortemente_conexo(TInstancia *instancia, int *s, int tams);

/**
 * Responsável carregar os dados da instância.
 * @param nome_instancia : nome do arquivo da instância
 * @return Estrutura de dados contendo os dados da instância
 */
inline TInstancia* carregarInstancias(char *nome_instancia) {
    TInstancia *inst;
    FILE *arquivoentrada;

    if ((arquivoentrada = fopen(nome_instancia, "r")) == NULL) {
        printf("Gráfico de entrada não existe");
        return NULL;
    }

    inst = lerarquivo(arquivoentrada);
    inst->nome_instancia = nome_instancia;
    printf("\n\n%s", nome_instancia);

    printf("\nvertices: %d", inst->num_vertices);
    printf("\narestas: %d", inst->num_arestas);
    printf("\ndensidade: %f", inst->densidade);
    printf("\n");
    return inst;
}

//-------------------------------- código para leitura e codificacao do problema

/**
 * Função auxiliar, que lê os dados do arquivo da instância(fp).
 *   Utilizada pelo carregarInstancia.
 * Formato do arquivo:
 *       p edge 1150 579607
 *       d 0.95
 *       e 1 25
 *       e 1 27
 *       e 1 31
 *       e 1 32
 *       e 1 34
 *       e 1 35
 *       e 1 36
 * @param arquivo: Arquivo que contém a instância. Precisa ter extensao clq
 * @return Uma estrutura de dados que representa os dados de uma instância
 */
TInstancia* lerarquivo(FILE *arquivo) {
    TInstancia *instancia = (TInstancia *) malloc(sizeof (TInstancia));

    char linha[100];
    int result, n1, n2;
    char d;
    while (!feof(arquivo)) //lendo arquivo e recebendo os conteúdos
    {
        //preenchendo a matriz com o conteúdo lido
        if (fgets(linha, 100, arquivo) != NULL) // Se foi possível ler
        {
            sscanf(linha, "%c", &d);
            if (d == 'p') {
                sscanf(linha, "p edge %d %d", &instancia->num_vertices, &instancia->num_arestas);
                float dtemp;
                result = fscanf(arquivo, "%c %f", &d, &dtemp); // linha, coluna e valor da aresta
                instancia->densidade = dtemp;
                break;
            }
        }
    }

    if (instancia->num_vertices > MAX_V) {
        printf("Quantidade de Vértices acima do limite! Recompile com MAX_V > %d\n", instancia->num_vertices);
        exit(0);
    }

    int i,j;
    for (i = 1; i <= instancia->num_vertices; i++) {
        instancia->vetorvizinhos[i] = 0;
        for (j = 1; j <= instancia->num_vertices; j++) {
            instancia->matrizadjacencia[i][j] = 0;
        }
    }

    while (!feof(arquivo)) //lendo arquivo e recebendo os conteúdos
    {
        //preenchendo a matriz com o conteúdo lido
        result = fscanf(arquivo, "%c %d %d\n", &d, &n1, &n2); // linha, coluna e valor da aresta
        if (result && d == 'e') {
            instancia->matrizadjacencia[n1][n2] = 1;
            instancia->matrizadjacencia[n2][n1] = 1;
            instancia->vetorvizinhos[n1]++;
            instancia->vetorvizinhos[n2]++;
        }
    }
    return instancia;
}

/**
 * Verifica a existência de aresta entre os vértices. Utiliza a matriz de adjacencia.
 * @param instancia : Estrutura de dados que representa os dados da instância
 * @param vertice1 : número do primeiro vértice a ser comparado
 * @param vertice2 : número do segundo vértice a ser comparado
 * @return 1 se houver aresta ou 0 se não houver aresta
 */
int existearesta(TInstancia *instancia, int vertice1, int vertice2) {
    return instancia->matrizadjacencia[vertice1][vertice2];
}

/**
 * verifica se uma determinada solução s é fortemente conexa.
 * @param instancia: Estrutura de dados que representa a instância
 * @param s : Um vetor contendo os vértices presentes na solução
 * @param tams : Um número inteiro que representa o tamanho da solução.
 * @return 1 se a solução é fortemente conexa e 0 se não for.
 */
inline int e_fortemente_conexo(TInstancia *instancia, int *s, int tams) {
    int conectado[tams];
    int i;
    for (i = 0; i < tams; i++)
        conectado[i] = 0;
    econexo(instancia, s, tams, 0, conectado);
    for (i = 0; i < tams; i++)
        if (conectado[i] == 0)
            return 0;
    return 1;

}

/*
    Verifica se o grafo da solução é conexo, função recursiva utilizada pela função validasolucao
    Entrada:
        Estrutura de dados contendo a instância
        solução a ser testada (vetor com os números dos vértices)
        tamanho da solução (tamanho do vetor)
        o vertice atual avaliado
        um vetor que irá indicar quais os vértices que estão conectados a solucao
    Descriçao:
        Busca em profundidade que marca o vertice como conectado.
 */
inline void econexo(TInstancia *instancia, int *s, int tams, int atual, int *conectado) {
    int i;
    int proximo;
    conectado[atual] = 1;
    for (i = 0; i < tams; i++) {
        proximo = i;
        if (conectado[proximo] == 0) {
            if (existearesta(instancia, s[atual], s[proximo])) {
                conectado[proximo] = 1;
                econexo(instancia, s, tams, proximo, conectado);
            }
        }
    }
}

#endif
