#include "HCB.h"

void atualizaVertices(TInstancia *instancia, TSolucao *dados, int verticeremovido);
double executarIG(TInstancia *instancia);
void ig(TInstancia *instancia, TSolucao *s_atual);
void geraLCD(TInstancia *instancia, TSolucao *dados);

/**
 * Função executora do IG, controla a fase de construção inicial e a chamada ao IG.
 * @param chaves
 * @param instancia
 * @return 
 */
double executarIG(TInstancia *instancia) {
    TSolucao *solucao = NULL;
    solucao = hcb(instancia, NULL);
    ig(instancia, solucao);
    double resultado = solucao->verticesolucao;
    free(solucao);
    return resultado;
}

/**
 * Função principal do decoder BRKGAIG*, ele recebe a solução inicial e 
 * remove um conjunto de vértices e então faz o processo de reconstrução.
 * @param chaves : conjunto com 2|V| chaves
 * @param instancia : instância do problemas
 * @param dados : a solução inicial
 * @return 
 */
void ig(TInstancia *instancia, TSolucao *solucao) {
    int escolha;
    int qtd_excluir;
    int j;

    TSolucao *s_temp = (TSolucao *) malloc(sizeof (TSolucao)); // cópia com ponteiro
    memcpy(s_temp, solucao, sizeof (TSolucao));
    while (1) {

        qtd_excluir = s_temp->verticesolucao * instancia->delta; //outra mudança
        for (j = 0; j < qtd_excluir; j++) {
            s_temp->tipo_ordenacao = GRAU_PARA_S;
            geraLCD(instancia, s_temp); // preenche a lista de candidatos CL
            geraLRC(instancia, s_temp, instancia->beta); // preenche a lista LRC
            escolha = selecionaLRC(s_temp, instancia->ordem_indice_remover);
            atualizaVertices(instancia, s_temp, escolha); // atualiza a solução s_atual
        }
        hcb(instancia, s_temp);
        if (solucao->verticesolucao < s_temp->verticesolucao) {
            if (e_fortemente_conexo(instancia, s_temp->solucao, s_temp->verticesolucao) == 1)
                memcpy(solucao, s_temp, sizeof (TSolucao));
            else {
                break;
            }
        } else
            break;
    }
    free(s_temp);
}

/*
    Função responsável em atualizar a lista de vértices.
    Inicializa alguns valores
    Entrada :
        - A estrutura de dados contendo os dados da instância
        - A estrutura de dados contendo os dados do HCB, esta estrutura que será atualizada
        - O número do vértice inserido na solução corrente
    Descrição :
        - Envia o vértice inserido para o final do vetor e decrementa o tamanho do vetor.
        - O vertice inserido não é atualizado
        - atualiza o vetor de grau para a solução
        - atualiza o vetor de grau para o conjunto y-vizinhos
        - atualiza o vetor de densidades caso o vértice seja inserido
        - marca o vértice inserido como não membro de y-vizinhos
        - modifica o valor de grau para y-vizinhos do vertice inserido para 0
 */
void atualizaVertices(TInstancia *instancia, TSolucao *solucao, int verticeremovido) {
    int i;
    for (i = 0; i < solucao->verticesolucao; i++) {
        if (solucao->solucao[i] == verticeremovido) {
            solucao->solucao[i] = solucao->solucao[(solucao->verticesolucao) - 1];
            break;
        }
    }
    solucao->verticesolucao = solucao->verticesolucao - 1;
    solucao->arestassolucao = solucao->arestassolucao - solucao->v_grauS[verticeremovido];
    solucao->v_em_S[verticeremovido] = 0;
    // solucao->v_em_NyS já é 0 para o vértice pois o mesmo estava na solução.
    // grau_em_NyS não é atualizado, pois a NyS precisa estar vazia nesse momento. Validado
    for (i = 1; i <= instancia->num_vertices; i++) {
        // Se existe a aresta entre o vértice atual e o vértice inserido na solução, aumentar o grau do vértice para a solução.
        // O grau do vértice para a solução será a quantidade de arestas a serem inseridas na solução, caso o vértice seja inserido.
        if (existearesta(instancia, i, verticeremovido))
            solucao->v_grauS[i] = solucao->v_grauS[i] - 1;
        if (solucao->verticesolucao == 0)
            solucao->v_denS[i] = 1.0;
        else {
            if (solucao->v_em_S[i] == 1) {
                solucao->v_denS[i] = (solucao->arestassolucao
                        /
                        (((solucao->verticesolucao)*(solucao->verticesolucao - 1)) / 2.0));
            } else {
                solucao->v_denS[i] = ((solucao->arestassolucao + solucao->v_grauS[i])
                        /
                        (((solucao->verticesolucao + 1)*(solucao->verticesolucao)) / 2.0));
            }
        }
    }

}

/*
    Função responsável em gerar a lista de candidatos a serem excluidos da lista de soluções, utilizando a ordenação por grau para a solução
    Inicializa alguns valores
    Entrada :
        - A estrutura de dados contendo os dados da solucao, esta estrutura que será atualizada
    Descrição :
        - inicializa a lista de candidatos, colocando o seu tamanho como 0
        - Insere elementos no MaxHeap LC ordenando por grau para solução
 */
void geraLCD(TInstancia *instancia, TSolucao *solucao) {
    solucao->tamanhoLC = 0;
    int i;
    for (i = 0; i < solucao->verticesolucao; i++) {
        insereHeap(instancia, solucao, solucao->solucao[i]);
    }

}

