#include <iostream>
#include <fstream>
#include <sys/resource.h>
#include <string.h>

#include "Decodificador.h"
#include "MTRand.h"
#include "BRKGA.h"
#include "tempo.h"

// funções opcionais
#define CAPTURA_GERACOES 0      // utilizado para capturar o tempo de cada geração e o fitness de cada individuo.
#define IMPRIME_RESULTADOS 0    // habilita a impressão detalhada dos resultados. 

// constantes:
#define GERACOES 100000     // quantidade de gerações 
#define META 5700           // valor alvo a ser alcançado
#define EXECUCOES 1         // quantidade de execuções que será realizada para uma instância
#define MAX_INSTANCIAS  100 // número máximo de instâncias - uso em execução em lote
#define RESTART   100000    // quantidade de gerações (sem melhoria) para o restart
#define SEMENTE 1           // define a semente inicial para as várias execuções.


// Estruturas de dados

typedef struct {
    std::vector< std::pair< double, unsigned > > fitness;
} TResposta; // essa estrutura de dados foi utilizada para montar o gráfico de pontos, salva o fitness de cada individuo de uma população

// parâmetros originais do BRKGA
int n; // size of chromosomes  : tamanho do cromossomo
int p; // size of population   : tamanho da população
double pe; // fraction of population to be the elite-set : tamanho da população elite
double pm; // fraction of population to be replaced by mutants : tamanho da população mutante
double rhoe; // probability that offspring inherit an allele from elite parent : probabilidade de herdar do pai elite
unsigned K = 1; // (NÃO UTILIZADA - VALOR PADRÃO) number of independent populations : número de populações independentes
unsigned MAXT = 1; // (NÃO UTILIZADA - VALOR PADRÃO) number of threads for parallel decoding : número de processos paralelos

// parâmetro especifico do quaseclique
float alfa; // parâmetro utilizado para definir a proporção de elementos a serem inseridos na LRC utilizada pelo HCB
int minsize; // parâmetro utilizado para definir o tamanho mínimo da lista LRC
float delta; // parâmetro utilizado para definir a quantidade de elementos a serem removidos da solução. Utilizado no IG.
float beta; // parâmetro utilizado para definir a proporção de elementos a serem inseridos na LRC durante a remoção. Utilizado no IG.
unsigned long long semente = SEMENTE;

// variáveis utilizadas para controlar os experimentos
int meta = META; // utilizado nos experimentos no qual o algoritmo busca um valor alvo (meta)
int execucoes = EXECUCOES; // define a quantidade de execuções que será realizada em uma determinada instância
int limiteGeracoes = GERACOES; // utilizado nos experimentos no qual o critério de parada considera a quantidade de gerações
char *nome_instancia; // nome da instância atual que está sendo tratada (.clq)
double tempo_limite; // utilizado nos experimentos no qual o critério de parada considera o tempo de execução
int qtd_instancias = 1; // quantidade de instâncias que serão tratadas em lote. Padrão igual a 1 (uma instância)
char *instacias[MAX_INSTANCIAS]; // vetor que armazena os nomes das instâncias que serão executadas. 
double tempoInstancia[MAX_INSTANCIAS]; // tempos de execução para cada instância, para esse tipo de critério de parada.
int limite = RESTART; // exchange best individuals at every 100 generations :  controla o restart, quantidade de gerações sem melhoria.

// variáveis utilizadas para armazenar informações dos experimentos
TResposta respostas[EXECUCOES][GERACOES]; // armazena a tupla (individuo-fitness) para gerar graficos de pontos
int contresp = 0; // utilizado no preenchimento da matriz respostas, geração atual
int qtdresp[EXECUCOES]; // utilizado no preenchimento da matriz respostas, recebe contresp
float tempos_geracoes[EXECUCOES][GERACOES]; // armazena o tempo gasto em cada geração.

// assinatura de funções utilizadas nesse arquivo.
void Tempo_CPU_Sistema(double *seg_CPU_total, double *seg_sistema_total);
int carregarInstancias();
void carregarParametros(char* argv[]);
void definirParametrosManualmente();
void preencherResposta(const std::vector< std::pair< double, unsigned > > fitness, int execucao);

/**
 * Função Main
 * @param argc : utilizado pelo Irace na parametrização
 * @param argv : utilizado pelo Irace na parametrização
 * @return 
 */
int main(int argc, char* argv[]) {
    // variáveis locais:    
    double s_CPU_inicial, s_CPU_final; // utilizado na marcação do tempo
    double s_total_inicial, s_total_final; // utilizado na marcação do tempo
    int i; // controla loop das execuções
    int j; // controla loop das instâncias
    double tempo[execucoes]; // armazena o tempo gasto em cada execução
    int geracoes[execucoes]; // armazena a quantidade de gerações gasto em cada execução
    int melhorsolucao[execucoes]; // armazena a melhor solução em cada execução
    int sem_melhoria = 0; // utilizado no restart e controla a quantidade de gerações sem melhoria
    double melhorS = 0.0; // armazena a melhor solução dentro de uma interação do restart
    double melhorGeral = 0.0; // armazena a melhor solução entre todas as iterações do restar

    if (argv[1] != NULL)
        carregarParametros(argv); // utilizado em parametrização pelo Irace
    else
        definirParametrosManualmente(); // utilizado em experimentos

    // controla a execução das várias instâncias em lote
    for (j = 0; j < qtd_instancias; j++) {
        semente = SEMENTE;
        Decodificador decoder; // inicializa o decodificador, não faz nada
        nome_instancia = instacias[j]; // recebe a instância atual
        tempo_limite = tempoInstancia[j]; // recebe o tempo da instância atual
        Tempo_CPU_Sistema(&s_CPU_inicial, &s_total_inicial); // captura o tempo inicial da execução da instância - carregamento

        if (decoder.defineInstancias(nome_instancia, alfa, minsize, delta, beta) == 1)
            printf("Erro no carregamento da instância %s", nome_instancia);
        else {
            Tempo_CPU_Sistema(&s_CPU_final, &s_total_final); // captura o tempo final do carregamento
            std::cout << "\nTempo para Carregar a Instância: " << (float) s_CPU_final - s_CPU_inicial << std::endl;

            n = decoder.getN()*2; // o tamanho do cromossomo é o dobro da quantidade de vértices            
            for (i = 0; i < execucoes; i++) {
                MTRand rng(semente++); // define a semente a ser utilizada no experimento/execução
                sem_melhoria = 0;
                contresp = 0;
                Tempo_CPU_Sistema(&s_CPU_inicial, &s_total_inicial); // tempo de inicio da execução
                // constroi a primeira população
                BRKGA< Decodificador, MTRand > algorithm(n, p, pe, pm, rhoe, decoder, rng, K, MAXT);
                int geracao = 0; // current generation : geração atual
                melhorS = -1 * algorithm.getBestFitness();
                melhorGeral = melhorS; // utilizado para o restart
                do {
                    if (melhorGeral < meta) {   
                        sem_melhoria++;
                        geracao++;
                        algorithm.evolve(); // evolui a população
                        //std::cout << "\n execucao:" << i << "(" << geracao << ")" << ": melhor solucao: " << melhorGeral << ": solucao: " << -1 * algorithm.getBestFitness() << std::endl;

                    } else {
                        if (geracao == 0) {
                            geracao = 1;
                            //std::cout << "\n execucao:" << i << "(" << geracao << ")" << ": melhor solucao: " << melhorGeral << ": solucao: " << -1 * algorithm.getBestFitness() << std::endl;
                            sem_melhoria = 1;
                        }
                        break;
                    }

                    if (melhorS <-1 * algorithm.getBestFitness()) {
                        melhorS = -1 * algorithm.getBestFitness();
                        sem_melhoria = 0;
                        if (melhorGeral < melhorS)
                            melhorGeral = melhorS;
                    }

                    if (sem_melhoria == limite) {
                        //std::cout << "\nrestart" << std::endl;
                        std::cout << "\n execucao:" << i << "(" << geracao << ")" << ": melhor solucao: " << melhorGeral << ": solucao: " << -1 * algorithm.getBestFitness() << std::endl;
                        algorithm.reset();      // reinicia a população
                        sem_melhoria = 0;
                        melhorS = -1 * algorithm.getBestFitness();
                        if (melhorGeral < melhorS)
                            melhorGeral = melhorS;
                    }
                    Tempo_CPU_Sistema(&s_CPU_final, &s_total_final);
                    if (CAPTURA_GERACOES == 1) { // não testei em instâncias em lote
                        tempos_geracoes[i][geracao - 1] = (float) s_CPU_final - s_CPU_inicial;
                        preencherResposta(algorithm.getPopulation(0).getFitness(), i);
                    }
                } while ((float) s_CPU_final - s_CPU_inicial <= tempo_limite);

                tempo[i] = (float) s_CPU_final - s_CPU_inicial;
                std::cout << "Execucao:: " << i + 1 << std::endl;
                std::cout << "Tempo:: " << (float) s_CPU_final - s_CPU_inicial << std::endl;
                std::cout << "Melhor " << melhorGeral << std::endl;
                std::cout << "Geracoes " << geracao << std::endl;
                std::cout << "Best " << -1 * melhorGeral << std::endl; // necessário para o IRACE

                tempo[i] /= MAXT;
                geracoes[i] = geracao;
                melhorsolucao[i] = melhorGeral;
                qtdresp[i] = contresp;
            }
            if (IMPRIME_RESULTADOS == 1) {
                char nome_arquivo[200] = "";

                strcat(nome_arquivo, nome_instancia);
                strcat(nome_arquivo, ".result");

                std::ofstream fout(nome_arquivo); 
                //em modo texto
                double media_sol = 0.0;
                double melhor_sol = 0.0;
                for (i = 0; i < execucoes; i++) {
                    media_sol += melhorsolucao[i];
                    if (melhor_sol < melhorsolucao[i])
                        melhor_sol = melhorsolucao[i];
                }
                media_sol /= execucoes;
                fout << "\nMédia  solução = " << media_sol;
                fout << "\nMelhor solução = " << melhor_sol;

                fout << "\n\nResultados da execução:\n\nTempo:\n\n";
                for (i = 0; i < execucoes; i++) {
                    fout << tempo[i] << "\n";
                }
                fout << "\n\nGerações\n\n";
                for (i = 0; i < execucoes; i++) {
                    fout << geracoes[i] << "\n";
                }
                fout << "\n\nSoluções\n\n";
                for (i = 0; i < execucoes; i++) {
                    fout << melhorsolucao[i] << "\n";
                }

                if (CAPTURA_GERACOES == 1) { // testar em lote
                    int k, t;
                    fout << "\n\nTempo Geracoes\n";
                    for (i = 0; i < execucoes; i++) {
                        fout << "\n" << i + 1 << " Execucao:\n";
                        for (t = 0; t < geracoes[i]; t++) {
                            fout << t + 1 << "\t" << tempos_geracoes[i][t] << "\n";
                        }
                    }

                    fout << "\n\nFitness\n";
                    for (i = 0; i < execucoes; i++) {
                        fout << "\n" << i + 1 << " Execucao:\n";
                        for (t = 0; t < qtdresp[i]; t++) {
                            for (k = 0; k < p; k++) {
                                fout << t + 1 << "\t" << -1 * respostas[i][t].fitness[k].first << "\n";
                            }
                        }
                    }

                }
            }
        }
    }
    return 0;
}

/**
 * Procedimento utilizado para inicializar os parametros através dos valores passados para a função.
 * Utilizado no IRACE
 * @param argv
 */
void carregarParametros(char* argv[]) {
    definirParametrosManualmente();
    nome_instancia = argv[5];
    semente = atoll(argv[7]);
    p = atof(argv[9]);
    pe = atof(argv[11]);
    pm = atof(argv[13]);
    rhoe = atof(argv[15]);
    int i = 0;
    for (i = 0; i < 15; i++)
        printf("\n%d parametro = %s", i + 1, argv[i]);
    printf("\np = %d", p);
    printf("\npe = %.2f", pe);
    printf("\npm = %.2f", pm);
    printf("\nrhoe = %.2f", rhoe);
    printf("\nInstancia = %s\n", nome_instancia);
    printf("\nSemente = %llu\n", semente);

    qtd_instancias = 0;
    instacias[qtd_instancias] = nome_instancia;
    tempoInstancia[qtd_instancias++] = 3600;
}

/**
 * Procedimento responsável em inicializar manualmente os parametros
 */
void definirParametrosManualmente() {
    alfa = 0.01;
    minsize = 3;    
    beta = 0.02;
    delta = 0.4;
    pe = 0.16;
    pm = 0.11;
    rhoe = 0.77;
    p = 89;

    qtd_instancias = 0;
    instacias[qtd_instancias] = (char*) "./instancias/frb40-19-4.clq";
    //instacias[qtd_instancias] = (char*) "./instancias/temp.clq";
    tempoInstancia[qtd_instancias++] = 61;
}

/**
 * Essa função permite armazenar o fitness para os individuos em uma determinada geração.
 * 
 * @param fitness : contém um vetor de fitness dos individuos, na ordem dos números deles.
 * @param execucao : armazena a execucao atual
 */
void preencherResposta(const std::vector< std::pair< double, unsigned > > fitness, int execucao) {
    respostas[execucao][contresp++].fitness = fitness; // a variável contresp++ define a geracao atual.
}