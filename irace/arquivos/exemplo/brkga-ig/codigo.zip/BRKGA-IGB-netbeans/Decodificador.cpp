#include <iostream>
#include "Decodificador.h"
#include "IGB.h"


Decodificador::Decodificador() {

}

Decodificador::~Decodificador() {
}

/**
 * Decoder BRKGA-IG*
 * @param chromosome : chromosome é um vetor que armazena os valores aleatórios gerados. tamanho = 2.|V|
 * @return 
 */
double Decodificador::decode(const std::vector< double >& chromosome) const {
    permutacao(chromosome);
    int resultado = -1 * executarIG(instancia); // o brkga foi projeta para minimizar, por isso o -1.
    return resultado;

}

/**
 * Retorna a quantidade de vértices presentes na instância. Utilizado no executor para definir o tamanho do cromossomo.
 * @return 
 */
int Decodificador::getN() {
    return instancia->num_vertices;
}

/**
 * Função responsável em inicializar os dados de uma instância
 * @param nome_instancia
 * @param alfa
 * @param minsize
 * @param delta
 * @param beta
 * @return 1 - se não foi possível carregar a instância e 0 se houve sucesso.
 */
int Decodificador::defineInstancias(char *nome_instancia, float alfa, int minsize, float delta, float beta) {
    free(instancia);
    instancia = NULL;
    instancia = carregarInstancias(nome_instancia);
    if (instancia == NULL) {
        return 1;
    }
    instancia->alfa = alfa;
    instancia->minsize = minsize;
    instancia->delta = delta;
    instancia->beta = beta;
    return 0;

}

/**
 * Função responsável em realizar a permutação entre os alelos presentes no cromossomo 
 * e os vértices presentes na instância.
 * Exemplo:
 * |V| = 4
 * chromosome = [0.1, 0.9, 0.5, 0.95, 0.3, 0.2, 0.05, 0.25]
 * ranking1 = [{0.1, 1}, {0.9, 2}, {0.5, 3}, {0.95, 4}]     - não ordenado
 * ranking2 = [{0.3, 1}, {0.2, 2}, {0.05, 3}, {0.25, 4}]    - não ordenado
 * ranking1 = [{0.1, 1}, {0.5, 3}, {0.9, 2},  {0.95, 4}]    - ordenado
 * ranking2 = [{0.05, 3}, {0.2, 2},  {0.25, 4}, {0.3, 1}]   - ordenado
 * ordem_indice_construir = [1, 3, 2, 4]                    - ordem_indice_construir[i] : posicao de i em ranking1
 * ordem_indice_remover = [4, 2, 1, 3]                      - ordem_indice_construir[i] : posicao de i em ranking2
 * @param chromosome
 */
void Decodificador::permutacao(const std::vector< double >& chromosome) const {
    std::vector< std::pair< double, unsigned > > ranking1(chromosome.size() / 2);
    std::vector< std::pair< double, unsigned > > ranking2(chromosome.size() / 2);
    int cont1 = 0;
    int cont2 = 0;
    for (unsigned i = 0; i < chromosome.size(); ++i) {
        if (i < chromosome.size() / 2) { //vincula os primeiras |V| chaves aos vértices
            ranking1[cont1] = std::pair< double, unsigned >(chromosome[i], cont1 + 1);
            cont1++;
        } else {                        //vincula as últimas |V| chaves aos vértices
            ranking2[cont2] = std::pair< double, unsigned >(chromosome[i], cont2 + 1);
            cont2++;
        }
    }
    std::sort(ranking1.begin(), ranking1.end());
    std::sort(ranking2.begin(), ranking2.end());
    std::vector< std::pair< double, unsigned > >::const_iterator proximo = ranking1.begin();
    int posicao = 1;
    while (proximo != ranking1.end()) {
        instancia->ordem_indice_construir[proximo->second] = posicao++;
        ++proximo;
    }
    proximo = ranking2.begin();
    posicao = 1;
    while (proximo != ranking2.end()) {
        instancia->ordem_indice_remover[proximo->second] = posicao++;
        ++proximo;
    }
}
