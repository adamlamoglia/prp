
#ifndef TEMPO_H_INCLUDED
#define TEMPO_H_INCLUDED

/*
   Um program em C para o projeto HC3 (versão 01/11/2014)
   Feito por Bruno Queiroz Pinto e Isabel Rosseti

    Esta biblioteca tem o objetivo de capturar o tempo do sistema, desconsiderando o tempo gasto pelo SO e demais tarefas.

    Contém as seguintes Funções:
    - Tempo_CPU_Sistema : responsável em capturar o tempo do sistema
*/


#include <sys/resource.h>


/*Assinatura das Funções */
void Tempo_CPU_Sistema(double *seg_CPU_total, double *seg_sistema_total);

/**
 * Captura o tempo do sistema
 * @param seg_CPU_total :Tempo total da cpu
 * @param seg_sistema_total : Tempo total do sistema
 */
void Tempo_CPU_Sistema(double *seg_CPU_total, double *seg_sistema_total)
{
  long seg_CPU, seg_sistema, mseg_CPU, mseg_sistema;
  struct rusage ptempo;

  getrusage(0,&ptempo);

  seg_CPU = ptempo.ru_utime.tv_sec;
  mseg_CPU = ptempo.ru_utime.tv_usec;
  seg_sistema = ptempo.ru_stime.tv_sec;
  mseg_sistema = ptempo.ru_stime.tv_usec;

 *seg_CPU_total     = (seg_CPU + 0.000001 * mseg_CPU);
 *seg_sistema_total = (seg_sistema + 0.000001 * mseg_sistema);
}

#endif

