
#ifndef HCB_H_INCLUDED
#define HCB_H_INCLUDED

/*
   Um programa em C para o projeto HCB (versão 05/07/2017)
   Feito por Bruno Queiroz Pinto

    Esta biblioteca contém as estruturas de dados e funções principais do HCB

    Contém as seguintes estruturas de dados:
    - TSolucao : Armazenas os dados da execução do HCB, bem como a solução encontrada

    Contém as seguintes Funções:
    - hcb : função principal do HCB, é a função pública da biblioteca, responsável em controlar o processamento
 */

#include "problema.h"

// tipos de ordenação
//utilizado na construção da solução
#define GRAU_VERTICE 0         //ORDENAR OS VÉRTICES PELA QUANTIDADE DE ARESTAS(GRAU) QUE SAEM DO VÉRTICE PARA OUTRO VÉRTICE
#define DIFERENCA_POTENCIAL 3  //ORDENAR PELA DIFERENCA DE POTENCIAL CAUSADO PELA INSERÇÃO DE UM VÉRTICE NOS DEMAIS VÉRTICES DE NyS
//utilizado na remoção de vértices
#define GRAU_PARA_S 1           // Ordena os vértices pelo seu grau para a solução corrente S

/*
    Armazenas os dados da execução do HCB, bem como a solução encontrada
 */
typedef struct {
    int tipo_ordenacao; // indica o tipo de ordenação atual da LRC

    int solucao[MAX_V]; // vetor contendo o número dos vértices na solução corrente
    int verticesolucao; // indica a quantidade de vértices na solução corrente
    int arestassolucao; // indica a quantidade de arestas na solução corrente

    int v_grau[MAX_V]; // vetor que pode ser utilizado para armazenar o grau dos vértices. Preenchido na instanciação.
    int v_grauS[MAX_V]; // vetor que pode ser utilizado para armazenar o grau dos vértices para a solução corrente. Atualizado sempre que um vértice for inserido ou removido.
    float v_denS[MAX_V]; // vetor que pode ser utilizado para armazenar a densidade dos vértices quando inseridos na solução. Atualizado sempre que um vértice for inserido ou removido.
    float v_diferenca[MAX_V]; // vetor que é utilizado para armazenar a diferença de potencial dos vértices. Não atualizado e sim calculado novamente quando necessário.
    int v_grau_p_NyS[MAX_V]; // vetor que pode ser utilizado para armazenar o grau dos vértices para o conjunto y-vizinhos. Atualizado sempre que um vértice for inserido ou removido.
    int v_em_NyS[MAX_V]; // vetor que pode ser utilizado para armazenar se um vértice esta(1) ou não(0) no conjunto y-vizinhos. Atualizado sempre que um vértice for inserido ou removido.
    int v_em_S[MAX_V]; // vetor que pode ser utilizado para armazenar se um vértice esta(1) ou não(0) no conjunto y-vizinhos. Atualizado sempre que um vértice for inserido ou removido.

    int lrc[MAX_V]; // heap contendo todos os elementos aptos, que produzam densidade suficientes, na iteração
    int tamanhoLRC; // indica o tamanho da lista restrita de candidatos - lrc
    int LC[MAX_V]; // heap contendo todos os elementos aptos, que produzam densidade suficientes, na iteração
    int tamanhoLC; // indica o tamanho da lista de candidatos, que também é a lista de Y-vizinhos quando necessário
} TSolucao;

/*
Assinaturas das funções
 */
TSolucao* hcb(const std::vector< double >& chaves, TInstancia *instancia, TSolucao *d);
TSolucao* criaSolucao();
void atualizaSolucao(TInstancia *instancia, TSolucao *dados, int verticeinserido);
float calculaDiferencaPotencial(TInstancia *instancia, TSolucao *dados, int vertice, int tamanhoNyS);
void geraNyS(TInstancia *instancia, TSolucao *dados);
void atualizaGrauNyS(TInstancia *instancia, TSolucao *dados, int vertice, int condicao);
void geraLRC(TInstancia *instancia, TSolucao *dados, float proporcao);
void iniciaSolucao(TInstancia *instancia, TSolucao *dados);
int deleteHeap(TInstancia *instancia, TSolucao *dados);
void insereHeap(TInstancia *instancia, TSolucao *dados, int novo);
double pegaChave(const std::vector< double >& chromosome, int tipo);
int selecionaLRC(TSolucao *dados, int chaves[]);

/**
 *  Função principal do algoritmo HCB, que controla a construção e reconstrução.
 * @param instancia - Estrutura de dados contendo os dados da instância
 * @param solucao - Estrutura de dados que representa uma solução preexistente, NULL para a primeira construção
 * @return uma solução nova ou a reconstrução da solução preexistente
 */
TSolucao* hcb(TInstancia *instancia, TSolucao *solucao) {

    int melhor = -1;

    //2: if S = ∅ then
    if (solucao == NULL) {
        solucao = criaSolucao();
        // preenche os dados da estrutura de dados do HCB
    }
    //2: if S = ∅ then
    if (solucao->verticesolucao == 0) {
        solucao->tipo_ordenacao = GRAU_VERTICE;
        //1: CL ← V \ S  == CL ← V : CL é ordenada por grau, estrutura em heap
        iniciaSolucao(instancia, solucao);

        // 3:. RCL ← {v ∈ CL : |{v 0 ∈ CL : deg G (v 0 ) ≥ deg G (v)}| ≤ max{minsize, α · |CL|}}
        geraLRC(instancia, solucao, instancia->alfa); //a lista com os vértices ordenados por grau (CL) foi gerada em montagrafo;
        // 4: x ← argmin{r j : j ∈ RCL}
        melhor = selecionaLRC(solucao, instancia->ordem_indice_construir);
    } else {
        solucao->tipo_ordenacao = DIFERENCA_POTENCIAL; // define ordenar por diferença de potencial
    }
    // 7: while CL != ∅ do
    while (1) {
        // 5: S ← {x}
        // 20: S ← S ∪ {x}
        if (melhor != -1) {
            solucao->solucao[solucao->verticesolucao] = melhor;
            solucao->verticesolucao = solucao->verticesolucao + 1;
            solucao->arestassolucao = solucao->arestassolucao + solucao->v_grauS[melhor];
            atualizaSolucao(instancia, solucao, melhor);
        }
        // for de 9 a 13 e for de 15 a 17
        solucao->tipo_ordenacao = DIFERENCA_POTENCIAL; // define ordenar por diferença de potencial
        geraNyS(instancia, solucao); // gera o conjunto NyS ordenado por diferença de potencial
        // 14: if CL != ∅ then
        if (solucao->tamanhoLC > 0) {
            // 18: RCL ← {v ∈ CL : |{v 0 ∈ CL : dif (v 0 ) ≥ dif (v)}| ≤ max{minsize, α · |CL|}}
            geraLRC(instancia, solucao, instancia->alfa);
        } else {
            // 7: while CL != ∅ do
            break;
        }
        // 19: x ← argmin{r j : j ∈ RCL}
        melhor = selecionaLRC(solucao, instancia->ordem_indice_construir);
    }
    // 23: return S.
    return solucao;
}

/**
 *    Função que cria a estrutura de dados para armazenar a solução produzida pelo HCB.
 *    Inicializa alguns valores da solução.
 *    @return    - A estrutura de dados que armazena uma solução vazia
 */
TSolucao* criaSolucao() {
    TSolucao *solucao = (TSolucao *) malloc(sizeof (TSolucao));
    solucao->arestassolucao = 0;
    solucao->verticesolucao = 0;
    solucao->tamanhoLRC = 0;
    solucao->tamanhoLC = 0;
    return solucao;
}

/**
 * Função responsável em atualizar as estruturas de dados que controlam a geração da solução.
 * Utilizamos estruturas de dados para armazena os valores calculados pelo HCB, de modo a evitar cálculos desnecessários.
 *     Descrição :
 *       - marca o vértice inserido como membro de S (v_em_S==1)
 *       - marca o vértice inserido como não membro de y-vizinhos (v_em_NyS==0)
 *       - atualiza o vetor de grau para a solução (v_grauS)
 *       - atualiza o vetor de grau para o conjunto y-vizinhos (v_grau_p_NyS) - não faz quando inseriu por grau do vértice, apenas por diferença de potencial.
 *       - atualiza o vetor de densidades (v_denS)
 * @param instancia : A estrutura de dados contendo os dados da instância
 * @param solucao : A estrutura de dados que armazena os dados da solução corrente
 * @param verticeinserido : O número do vértice inserido.
 */
void atualizaSolucao(TInstancia *instancia, TSolucao *solucao, int verticeinserido) {
    int i;
    solucao->v_em_S[verticeinserido] = 1;
    solucao->v_em_NyS[verticeinserido] = 0;

    for (i = 1; i <= instancia->num_vertices; i++) {
        // Se existe a aresta entre o vértice atual(i) e o vértice inserido na solução, aumentar o grau do vértice para a solução.
        if (existearesta(instancia, i, verticeinserido)) {
            solucao->v_grauS[i] = solucao->v_grauS[i] + 1;
            if (solucao->tipo_ordenacao == DIFERENCA_POTENCIAL) // só atualiza grau para NyS se estiver considerando Diferença de potencial.
                solucao->v_grau_p_NyS[i] = solucao->v_grau_p_NyS[i] - 1;
        }
        if (solucao->v_em_S[i] == 1) {
            solucao->v_denS[i] = (solucao->arestassolucao
                    /
                    (((solucao->verticesolucao)*(solucao->verticesolucao - 1)) / 2.0));
        } else {
            solucao->v_denS[i] = ((solucao->arestassolucao + solucao->v_grauS[i])
                    /
                    (((solucao->verticesolucao + 1)*(solucao->verticesolucao)) / 2.0));
        }
    }
}

/**
 * Função responsável em gerar a lista restrita de candidatos tanto na construção como na destruição.
 * @param solucao : Estrutura de Dados contendo a solução atual
 * @param proporcao : recebe o valor de alfa(construção) ou beta(destruição)
 * @param minsize : tamanho mínimo da lista de candidatos.
 */
void geraLRC(TInstancia *instancia, TSolucao *solucao, float proporcao) {
    solucao->tamanhoLRC = 0;
    int i;
    int tamanho;
    if (solucao->tamanhoLC <= instancia->minsize)
        tamanho = solucao->tamanhoLC;
    else {
        tamanho = proporcao * (solucao->tamanhoLC);
        if (tamanho < instancia->minsize)
            tamanho = instancia->minsize;
    }
    for (i = 1; i <= tamanho; i++) {
        solucao->lrc[(solucao->tamanhoLRC)++] = deleteHeap(instancia, solucao);
    }
}

/**
 * Essa função é responsável em gerar a Lista de candidatos LC contendo todos os vértices que tenham densidade gamma.
 * Se um vértice for inserido na lista precisa atualizar o vetor v_em_NyS e o v_grau_p_NyS(função atualizaNyS).
 * Se o vértice já estava nessa lista, não é necessário atualizar, evitamos processamento repetido.
 * 
 * Essa função também realiza a atualização do vetor de diferença de potencial (v_diferenca). 
 * Após esse cálculo é feito a ordenação da LC pela diferença de potencial.
 * 
 * @param instancia : Estrutura de dados contendo a instância do problema.
 * @param solucao : Estrutura de dados que contém a solução corrente do problema.
 */
void geraNyS(TInstancia *instancia, TSolucao *solucao) {
    int tamanhoNyS = 1;
    int i;
    // cria a Ny(S) sem ordem, com apenas vértices que tornam a solução S y-clique-maxima
    for (i = 1; i <= instancia->num_vertices; i++) {
        if (solucao->v_em_S[i] == 0 && solucao->v_grauS[i] > 0) {
            if (solucao->v_denS[i] >= instancia->densidade) { // uma das mudanças para o HC3
                if (solucao->v_em_NyS[i] == 0) {
                    solucao->v_em_NyS[i] = 1;
                    atualizaGrauNyS(instancia, solucao, i, 0);
                }
                solucao->LC[tamanhoNyS++] = i; // LC é um vetor sem ordem(diferença de potencial) aqui. Fica ordenado por número do vértice.
            } else {
                if (solucao->v_em_NyS[i] == 1) {
                    solucao->v_em_NyS[i] = 0;
                    atualizaGrauNyS(instancia, solucao, i, 1);
                }
            }
        }
    }
    solucao->tamanhoLC = 0;
    tamanhoNyS--;
    /* Calcula a diferença de potencial de cada um dos vértices presentes
     * Reinsere os elementos na heap(LC) em ordem decrestente do valor da diferença de potencial. 
     * Necessário outro loop, pois no anterior não conheciamos o tamanho da Nys
     * exemplo:
     * INICIO:
     * LC
     *     V    = {1, 4, 50, 56, 100}
     *     dif  = {não calculado}
     * FIM:
     * LC
     *     V    = {4,   56,     50,     1,      100}
     *     dif  = {0.9, 0.85,   0.8,    0.3,    0.7}
     */
    for (i = 1; i <= tamanhoNyS; i++) {
        solucao->v_diferenca[solucao->LC[i]] = calculaDiferencaPotencial(instancia, solucao, solucao->LC[i], tamanhoNyS);
        insereHeap(instancia, solucao, solucao->LC[i]);
    }
}

/**
 * Função responsável em atualizar os dados do vetor v_grau_p_NyS após a inclusão ou remoção de um vértice na lista de vizinhos NyS.
 * @param instancia : Estrutura de dados que contém os dados da instância.
 * @param solucao : Estrutura de dados que contém os dados da solução corrente.
 * @param vertice : Número do vértice que esta sendo inserido ou removido da NyS.
 * @param condicao : 0 - inserindo e 1 - removendo.
 */
void atualizaGrauNyS(TInstancia *instancia, TSolucao *solucao, int vertice, int condicao) {
    int i;
    for (i = 1; i <= instancia->num_vertices; i++) {
        if (i != vertice) {
            if (existearesta(instancia, i, vertice)) {
                if (condicao == 0)
                    solucao->v_grau_p_NyS[i] = solucao->v_grau_p_NyS[i] + 1;
                else
                    solucao->v_grau_p_NyS[i] = solucao->v_grau_p_NyS[i] - 1;
            }
        }
    }
}

/**
 * Método responsável em calcular a diferença de potencial
 * @param instancia : Estrutura de dados contendo os dados da instância
 * @param solucao : Estrutura de dados que contém a solução corrente.
 * @param vertice : Número do vértice que terá a sua diferença de pontêncial calculada.
 * @param tamanhoNyS : Tamanho da lista de candidatos que são vizinhos de S e tenham densidade y (NyS).
 * @return Número real que representa o valor de diferença de potencial
 */
float calculaDiferencaPotencial(TInstancia *instancia, TSolucao *solucao, int vertice, int tamanhoNyS) {
    //difv ← degG(CL)(v) + |CL| · (degG(S)(v) − γ·(|S| + 1))
    //grau_do_vertice_para_o_conjunto_NyS: solucao->v_grau_p_NyS[vertice];
    //tamanho do conjunto NyS: tamanhoNyS;
    //grau_do_vertice_para_o_conjunto_S: solucao->v_grauS[vertice];
    //Número de vértices na solução : solucao->verticesolucao;
    return
    solucao->v_grau_p_NyS[vertice] +
            tamanhoNyS *
            (solucao->v_grauS[vertice] - instancia->densidade * (solucao->verticesolucao + 1));
}

/**
 * Essa função é utilizada na criação de uma nova solução, inicializando os vetores utilizandos na construção da solução.
 * Ela também é responsável em gerar a primeira lista de candidatos, ordenados pelo grau para a solução.
 * @param instancia : Estrutura de dados que armazena os dados da instância.
 * @param solucao : Estrutura de dados que armazena os dados da solução corrente.
 */
void iniciaSolucao(TInstancia *instancia, TSolucao *solucao) {
    int i;
    solucao->tamanhoLC = 0;
    solucao->tamanhoLRC = 0;
    for (i = 1; i <= instancia->num_vertices; i++) {
        solucao->v_grau[i] = instancia->vetorvizinhos[i];
        solucao->v_grauS[i] = 0;
        solucao->v_denS[i] = 0.0;
        solucao->v_diferenca[i] = 0.0;
        solucao->v_grau_p_NyS[i] = 0;
        solucao->v_em_NyS[i] = 0;
        solucao->v_em_S[i] = 0;
        insereHeap(instancia, solucao, i);
    }
}

/**
 * Função responsável em selecionar um vértice da LRC.
 * A função utiliza a ordem gerada pela permutação entre as chaves e os vértices. * 
 * @param solucao : Estrutura de Dados contendo a solução corrente.
 * @param ordem : vetor utilizado para definir a ordem entre os vértices.
 *                  O i-ésimo elemento do vetor ordem, representa o vértice com número i 
 *                  e contém a posição dele na ordenação feita pela permutação entre vértices e chaves.
 *                  Dentre os candidatos, aquele que tiver a menor posição, tinha a menor chave e será selecionado.
 *                  Exemplo:
 *                  chaves:     [0.5, 0.3, 0.1]
 *                  vértices:   [1  , 2  , 3  ]
 *                  ordem:      [3  , 2  , 1  ]
 *                  LRC:        [1  , 3 ]
 *                  retorna 3, pois ele tem a menor ordem e consequentemente a menor chave entre os elementos de LRC.
 * @return retorna o vértice que tenha a menor chave vinculada a ele.
 */
int selecionaLRC(TSolucao *solucao, int ordem[]) {
    int vertice = solucao->lrc[0];
    int menor = ordem[vertice];
    int verticetemp, temp;
    int i;
    for (i = 1; i < solucao->tamanhoLRC; i++) {
        verticetemp = solucao->lrc[i];
        temp = ordem[verticetemp];
        if (temp < menor) {
            menor = temp;
            vertice = verticetemp;
        }
    }
    return vertice;
}

//------------------------------------ Métodos utilizados para implementar o Heap

/**
 * Utilizado para inserir elementos no heap, tal metodo é utilizado para gerar a LC
 * @param solucao : Estrutura de dados que representa a solução corrente.
 * @param novo : Número do vértice que está sendo inserido.
 */
void insereHeap(TInstancia *instancia, TSolucao *solucao, int novo) {
    (solucao->tamanhoLC)++;
    solucao->LC[solucao->tamanhoLC] = novo;
    int atual = solucao->tamanhoLC;

    if (atual > 1) {
        switch (solucao->tipo_ordenacao) {
            case GRAU_VERTICE:
                while (solucao->v_grau[solucao->LC[atual / 2]] < solucao->v_grau[novo]
                        ||
                        (solucao->v_grau[solucao->LC[atual / 2]] == solucao->v_grau[novo] && instancia->ordem_indice_construir[novo] < instancia->ordem_indice_construir[solucao->LC[atual / 2]])
                        ) {
                    solucao->LC[atual] = solucao->LC[atual / 2];
                    atual /= 2;
                    if (atual == 1)
                        break;
                }
                break;
                /* Exemplo Novo: 
                 * V    =   1       2       3       4       5       6
                 * Deg  =   5       5       5       5       5       5   
                 * r1   =   0.4170  0.7203  0.0001  0.3023  0.1467  0.0923
                 * ord  =   5       6       1       4       3       2        
                 * LC   =   3       5       6       2       4       1
                 * 
                 * HEAP=                3
                 *              5               6
                 *          2       4       1
                 */
            case DIFERENCA_POTENCIAL:
                while (solucao->v_diferenca[solucao->LC[atual / 2]] < solucao->v_diferenca[novo]
                        ||
                        (solucao->v_diferenca[solucao->LC[atual / 2]] == solucao->v_diferenca[novo] && instancia->ordem_indice_construir[novo] < instancia->ordem_indice_construir[solucao->LC[atual / 2]])
                        ) {
                    solucao->LC[atual] = solucao->LC[atual / 2];
                    atual /= 2;
                    if (atual == 1)
                        break;
                }
                break;
                /* Exemplo Novo: 
                 * V    =   1       2       4       5       6
                 * Dif  =   iguais
                 * r1   =   0.4170  0.7203  0.3023  0.1467  0.0923
                 * ord  =   5       6       4       3       2        
                 * LC   =   6       5       1       2       4
                 * 
                 * HEAP=                6
                 *              5               1
                 *          2       4       
                 */
            case GRAU_PARA_S:
                while (solucao->v_grauS[solucao->LC[atual / 2]] > solucao->v_grauS[novo]
                        ||
                        (solucao->v_grauS[solucao->LC[atual / 2]] == solucao->v_grauS[novo] && instancia->ordem_indice_construir[novo] < instancia->ordem_indice_construir[solucao->LC[atual / 2]])
                        ) {
                    solucao->LC[atual] = solucao->LC[atual / 2];
                    atual /= 2;
                    if (atual == 1)
                        break;
                }
                break;
                /* Exemplo Novo: 
                 * S    =   3       6       5       4       1       2
                 * DegS =   5       5       5       5       5       5   
                 * r1   =   0.0001  0.0923  0.1467  0.3023  0.4170  0.7203    
                 * ord  =   1       2       3       4       5       6        
                 * LC   =   3       6       5       4       1       2
                 * 
                 * HEAP=                3
                 *              6               5
                 *          4       1       2
                 */
        }
        solucao->LC[atual] = novo;
    }

}

/**
 * Método responsável em retirar um vértice do heap, utilizado para gerar a LRC
 * @param solucao Estrutura de dados que armazena a solução corrente.
 * @return O número do elemento que está na raiz será retornado e esse elemento retirado na heap.
 */
int deleteHeap(TInstancia *instancia, TSolucao *solucao) {
    int filho, atual, ultimoElemento;
    int melhor = solucao->LC[1];
    ultimoElemento = solucao->LC[solucao->tamanhoLC];
    for (atual = 1; atual * 2 <= solucao->tamanhoLC; atual = filho) {
        filho = atual * 2;
        if (solucao->tipo_ordenacao == GRAU_VERTICE) {
            if (filho != solucao->tamanhoLC && solucao->v_grau[solucao->LC[filho + 1]] > solucao->v_grau[solucao->LC[filho]]
                    ||
                    (filho != solucao->tamanhoLC && solucao->v_grau[solucao->LC[filho + 1]] == solucao->v_grau[solucao->LC[filho]] && instancia->ordem_indice_construir[solucao->LC[filho + 1]] < instancia->ordem_indice_construir[solucao->LC[filho]])
                    ) {
                filho++;
            }
            if (solucao->v_grau[ultimoElemento] < solucao->v_grau[solucao->LC[filho]]
                    ||
                    (solucao->v_grau[ultimoElemento] == solucao->v_grau[solucao->LC[filho]] && instancia->ordem_indice_construir[ultimoElemento] > instancia->ordem_indice_construir[solucao->LC[filho]])) {
                solucao->LC[atual] = solucao->LC[filho];
            } else {
                break;
            }
            /* Exemplo Novo: minsize = 6
             * V    =   1       2       3       4       5       6
             * Deg  =   5       5       5       5       5       5   
             * r1   =   0.4170  0.7203  0.0001  0.3023  0.1467  0.0923
             * ord  =   5       6       1       4       3       2        
             * LC   =   3       5       6       2       4       1
             * 
             * HEAP=                3
             *              5               6
             *          2       4       1
             * LRC  =   3       6       5       4       1       2
             */
        } else if (solucao->tipo_ordenacao == DIFERENCA_POTENCIAL) {
            if (filho != solucao->tamanhoLC && solucao->v_diferenca[solucao->LC[filho + 1]] > solucao->v_diferenca[solucao->LC[filho]]
                    ||
                    (filho != solucao->tamanhoLC && solucao->v_diferenca[solucao->LC[filho + 1]] == solucao->v_diferenca[solucao->LC[filho]] && instancia->ordem_indice_construir[solucao->LC[filho + 1]] < instancia->ordem_indice_construir[solucao->LC[filho]])
                    ) {
                filho++;
            }
            if (solucao->v_diferenca[ultimoElemento] < solucao->v_diferenca[solucao->LC[filho]]
                    ||
                    (solucao->v_diferenca[ultimoElemento] == solucao->v_diferenca[solucao->LC[filho]] && instancia->ordem_indice_construir[ultimoElemento] > instancia->ordem_indice_construir[solucao->LC[filho]])) {
                solucao->LC[atual] = solucao->LC[filho];
            } else {
                break;
            }
                /* Exemplo Novo: minsize = 6
                 * V    =   1       2       4       5       6
                 * Deg  =   5       5       5       5       5   
                 * r1   =   0.4170  0.7203  0.3023  0.1467  0.0923
                 * ord  =   5       6       4       3       2        
                 * LC   =   6       5       1       2       4
                 * 
                 * HEAP=                6
                 *              5               1
                 *          2       4  
                 * LRC  =   6       5       4       1       2     
                 */
        } else if (solucao->tipo_ordenacao == GRAU_PARA_S) {
            if (filho != solucao->tamanhoLC && solucao->v_grauS[solucao->LC[filho + 1]] < solucao->v_grauS[solucao->LC[filho]]
                    ||
                    (filho != solucao->tamanhoLC && solucao->v_grauS[solucao->LC[filho + 1]] == solucao->v_grauS[solucao->LC[filho]] && instancia->ordem_indice_construir[solucao->LC[filho + 1]] < instancia->ordem_indice_construir[solucao->LC[filho]])
                    ) {
                filho++;
            }
            if (solucao->v_grauS[ultimoElemento] > solucao->v_grauS[solucao->LC[filho]]
                    ||
                    (solucao->v_grauS[ultimoElemento] == solucao->v_grauS[solucao->LC[filho]] && instancia->ordem_indice_construir[ultimoElemento] > instancia->ordem_indice_construir[solucao->LC[filho]])
                    ) {
                solucao->LC[atual] = solucao->LC[filho];
            } else {
                break;
            }
                /* Exemplo Novo: minsize = 6
                 * S    =   3       6       5       4       1       2
                 * DegS =   5       5       5       5       5       5   
                 * r1   =   0.0001  0.0923  0.1467  0.3023  0.4170  0.7203    
                 * ord  =   1       2       3       4       5       6        
                 * LC   =   3       6       5       4       1       2
                 * 
                 * HEAP=                3
                 *              6               5
                 *          4       1       2
                 * LRC  =   3       6       5       4       1       2
                 */
        }
    }
    solucao->LC[atual] = ultimoElemento;
    (solucao->tamanhoLC)--;
    return melhor;
}

#endif
